package com.DarkshanDev.sinol

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
